const Users = require("../Models/user");
const Books = require("../Models/book");
var express = require("express");
var router = express.Router();
const jwt = require("jsonwebtoken")


const verifyToken = (req, res, next) => {
    const token = req.headers.authorization;
    if (!token) return res.status(403).send({ msg: "Token is required for authentication" });

    try {
        const decoded = jwt.verify(token.split(" ")[1], "MY_SECRET");
        req.user = decoded;
        next();
    } catch (error) {
        return res.status(401).send({ msg: "Invalid Token" });
    }
};

router.post("/createBook", async (req, res) => {
    try {
        const user = await Users.findOne({ email: req.body.email })
        if (!user) return res.json({ msg: "USER NOT FOUND" })

        try {
            const token = req.headers.authorization;
            jwt.verify(token.split(" ")[1], "MY_SECRET")
        } catch (e) {
            return res.json({ msg: "TOKEN NOT FOUND / INVALID" })
        }

        await Books.create({ ...req.body, user: user._id })

        res.json({ msg: "BOOK CREATED" })
    } catch (error) {
        console.error(error)
    }
});

router.get("/", verifyToken, async (req, res) => {
    try {
        const books = await Books.find({ user: req.user._id });
        res.json(books);
    } catch (error) {
        console.error(error);
        res.status(500).send(error);
    }
});

router.get("/:id", verifyToken, async (req, res) => {
    try {
        const book = await Books.findById(req.params.id);
        if (!book) return res.status(404).send({ msg: "Book not found" });
        res.json(book);
    } catch (error) {
        console.error(error);
        res.status(500).send(error);
    }
});

router.put("/:id", verifyToken, async (req, res) => {
    try {
        const updatedBook = await Books.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(updatedBook);
    } catch (error) {
        console.error(error);
        res.status(500).send(error);
    }
});

router.delete("/:id", verifyToken, async (req, res) => {
    try {
        const book = await Books.findByIdAndDelete(req.params.id);
        if (!book) return res.status(404).send({ msg: "Book not found" });
        res.send({ msg: "Book deleted" });
    } catch (error) {
        console.error(error);
        res.status(500).send(error);
    }
});

module.exports = router