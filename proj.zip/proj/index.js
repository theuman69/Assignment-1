var createError = require('http-errors')
var express = require('express')
const mongoose = require('mongoose')

var app = express()

app.use(express.json())
app.use(express.urlencoded({extended: false}))

(async () =>
{
    try{
        await mongoose.connect("mongodb://localhost:27017/test")
        console.log('connection was successful')
    } catch (error) {
        console.error('unable to connect to db', error)
    }
}) ()

const router = require('./Routes/index')
app.use('/', router)


app.use(function (req, res, next) {
  next(createError(404))

} )

  
const PORT = 5600
app.listen(PORT, console.log(`server running port ${PORT}`))




